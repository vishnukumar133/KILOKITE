# KiloKite — Startup Website

A responsive React + Vite website for KiloKite, designed for GitHub Pages.

## Run it on your computer

1. Install Node.js (LTS): https://nodejs.org/
2. Extract this ZIP folder.
3. Open the extracted `kilokite-website` folder in VS Code.
4. Open Terminal → New Terminal.
5. Run:

   ```bash
   npm install
   npm run dev
   ```

6. Open the local address shown in the terminal (usually http://localhost:5173).

## Publish free with GitHub Pages

This project includes a GitHub Actions workflow at `.github/workflows/deploy.yml`.

1. Sign in at https://github.com/
2. Create a **new public repository** named `kilokite-website`.
3. Upload the contents of this project folder to the repository (make sure `package.json`, `index.html`, `src/` and `.github/` are at the repository root).
4. Open the repository → **Settings** → **Pages**.
5. Under **Build and deployment**, choose **GitHub Actions** as the source.
6. Open the **Actions** tab. The workflow will build and publish the site after the files are pushed to the `main` branch.
7. When the workflow finishes successfully, open Settings → Pages to find your live website URL. It will look like `https://YOUR-USERNAME.github.io/kilokite-website/`.

Whenever you update and push changes to `main`, GitHub Actions republishes the site.

## Features

- Responsive layouts for desktop, tablet and mobile.
- Mobile navigation menu and smooth-scroll section links.
- Sample energy dashboard with weekly/monthly chart toggle.
- Working electricity bill calculator.
- Contact form with browser validation and an on-screen demo confirmation.

## Important notes

- Dashboard readings are illustrative sample values, not live smart-meter data.
- The savings calculator uses `monthly kWh × entered rate` and displays an illustrative 15% savings target. Real bills can include fixed charges, slabs, taxes and other adjustments.
- The contact form currently validates in the browser and displays a demo confirmation. It does not send or store messages. Connect a form backend/service to receive submissions.
- The website is a front-end prototype. Live meter integration, real-time tariff data and AI-powered recommendations require suitable APIs and a secure backend. Do not put private API keys in frontend code.
