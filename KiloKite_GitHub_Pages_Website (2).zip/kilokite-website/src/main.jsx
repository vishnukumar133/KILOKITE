import React, { useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  Activity, ArrowDownRight, ArrowRight, ArrowUpRight, BarChart3, BatteryCharging,
  Check, ChevronDown, CircleDollarSign, Clock3, Cpu, Gauge, Leaf, Lightbulb,
  Menu, PlugZap, ShieldCheck, Sparkles, TrendingDown, X, Zap
} from 'lucide-react'
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
  BarChart, Bar, Cell
} from 'recharts'
import './styles.css'

const usageData = [
  { day: 'Mon', usage: 18 }, { day: 'Tue', usage: 22 }, { day: 'Wed', usage: 16 },
  { day: 'Thu', usage: 25 }, { day: 'Fri', usage: 20 }, { day: 'Sat', usage: 14 },
  { day: 'Sun', usage: 19 }
]
const monthlyData = [
  { month: 'Jan', units: 310 }, { month: 'Feb', units: 285 }, { month: 'Mar', units: 330 },
  { month: 'Apr', units: 298 }, { month: 'May', units: 360 }, { month: 'Jun', units: 324 }
]
const solutions = [
  { icon: Activity, title: 'Smart Electricity Monitoring', text: 'See how much electricity you use and when you use it, with a clear view of your consumption.' },
  { icon: BarChart3, title: 'Energy Consumption Analysis', text: 'Turn everyday usage patterns into simple insights that help you make informed decisions.' },
  { icon: CircleDollarSign, title: 'Electricity Bill Estimation', text: 'Estimate your monthly electricity cost from your usage and your entered per-unit rate.' },
  { icon: Lightbulb, title: 'Energy Saving Recommendations', text: 'Discover practical ways to reduce avoidable energy use and manage your costs.' },
  { icon: Gauge, title: 'Usage Reports and Insights', text: 'Review daily and monthly trends through easy-to-understand visual reports.' }
]

function Brand({ light = false }) {
  return <a className={`brand ${light ? 'brand-light' : ''}`} href="#home" aria-label="KiloKite home">
    <span className="brand-mark"><span /><span /><span /></span>
    <span className="brand-word">Kilo<span>Kite</span><small>EVERY UNIT. SMARTER INSIGHTS.</small></span>
  </a>
}

function Header() {
  const [open, setOpen] = useState(false)
  const links = [['About', '#about'], ['Solutions', '#solutions'], ['Dashboard', '#dashboard'], ['Calculator', '#calculator']]
  return <header className="header">
    <div className="container nav-wrap">
      <Brand />
      <button className="mobile-toggle" onClick={() => setOpen(!open)} aria-label="Toggle navigation">{open ? <X /> : <Menu />}</button>
      <nav className={open ? 'nav nav-open' : 'nav'}>
        {links.map(([label, href]) => <a key={label} href={href} onClick={() => setOpen(false)}>{label}</a>)}
        <a className="nav-contact" href="#contact" onClick={() => setOpen(false)}>Let’s talk <ArrowRight size={16}/></a>
      </nav>
    </div>
  </header>
}

function DashboardVisual() {
  return <div className="hero-visual">
    <div className="visual-glow" />
    <div className="floating-tag tag-top"><span className="pulse-dot" /> Live energy overview</div>
    <div className="dash-window">
      <div className="dash-top"><div className="window-dots"><i/><i/><i/></div><span>ENERGY OVERVIEW</span><span className="live-label">● LIVE</span></div>
      <div className="dash-main">
        <div className="dash-heading"><div><small>YOUR ENERGY SNAPSHOT</small><h3>Good morning, Alex</h3></div><span className="avatar">A</span></div>
        <div className="dash-stats">
          <div className="dash-stat"><span>Total consumption</span><strong>324 <em>kWh</em></strong><small className="positive"><ArrowDownRight size={13}/> 8.4% vs last month</small></div>
          <div className="dash-stat"><span>Estimated bill</span><strong>₹2,268</strong><small>At ₹7.00 / unit</small></div>
        </div>
        <div className="mini-chart-head"><b>Weekly energy usage</b><span>Last 7 days⌄</span></div>
        <div className="mini-bars">{[48,66,42,78,58,35,52].map((v,i)=><div className="mini-bar-col" key={i}><div className="mini-bar" style={{height:`${v}%`}}/><small>{['M','T','W','T','F','S','S'][i]}</small></div>)}</div>
        <div className="insight-strip"><span className="insight-icon"><Sparkles size={16}/></span><span><b>A little insight</b><small>Shift heavy appliance use to off-peak hours.</small></span><ArrowRight size={15}/></div>
      </div>
    </div>
    <div className="floating-tag tag-bottom"><span className="tag-leaf"><Leaf size={15}/></span><span><b>Smarter energy habits</b><small>Start with one small change</small></span></div>
    <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
  </div>
}

function Hero() {
  return <section className="hero" id="home">
    <div className="container hero-grid">
      <div className="hero-copy">
        <div className="eyebrow"><span className="eyebrow-line"/> INTELLIGENCE FOR EVERY UNIT</div>
        <h1>Power smarter.<br/><span>Save better.</span></h1>
        <p className="hero-lead">Understand your electricity usage, discover energy-saving opportunities and make smarter energy decisions.</p>
        <div className="hero-actions"><a className="btn btn-primary" href="#solutions">Explore solutions <ArrowRight size={17}/></a><a className="btn btn-ghost" href="#calculator">Calculate savings <ArrowUpRight size={17}/></a></div>
        <div className="hero-proof"><div className="proof-icon"><ShieldCheck size={17}/></div><span>Clear insights. Practical actions. Better energy habits.</span></div>
      </div>
      <DashboardVisual/>
    </div>
    <div className="hero-bottom container"><span>ENERGY, MADE UNDERSTANDABLE</span><div/><span>MONITOR · ANALYSE · OPTIMISE</span></div>
  </section>
}

function About() {
  return <section className="section about-section" id="about">
    <div className="container about-grid">
      <div><div className="eyebrow"><span className="eyebrow-line"/> ABOUT KILOKITE</div><h2>Make every unit<br/> <span>count.</span></h2></div>
      <div className="about-copy"><p className="section-lead">KiloKite is a smart energy technology concept designed to make electricity data easier to understand and act on.</p><p>We bring consumption tracking, cost estimates and practical energy-saving guidance into one simple experience — helping households and businesses take a more informed approach to energy use.</p>
        <div className="mission-grid"><div><span className="mission-icon"><Zap size={18}/></span><h3>Our mission</h3><p>To make energy usage smarter, simpler and more efficient.</p></div><div><span className="mission-icon cyan"><Sparkles size={18}/></span><h3>Our vision</h3><p>A future where everyone can understand and optimise their energy consumption.</p></div></div>
      </div>
    </div>
  </section>
}

function Solutions() {
  return <section className="section solutions-section" id="solutions">
    <div className="container"><div className="section-top"><div><div className="eyebrow"><span className="eyebrow-line"/> WHAT WE DO</div><h2>Energy clarity.<br/><span>Built into every step.</span></h2></div><p>Everything you need to move from simply paying your bill to understanding the energy behind it.</p></div>
      <div className="solution-grid">{solutions.map((s,i)=><article className="solution-card" key={s.title}><div className="solution-icon"><s.icon size={22}/></div><span className="card-number">0{i+1}</span><h3>{s.title}</h3><p>{s.text}</p><a href="#dashboard" aria-label={`Explore ${s.title}`}><ArrowUpRight size={18}/></a></article>)}</div>
    </div>
  </section>
}

function Dashboard() {
  const [period, setPeriod] = useState('Week')
  const data = period === 'Week' ? usageData : monthlyData
  return <section className="section dashboard-section" id="dashboard">
    <div className="container"><div className="section-top dashboard-top"><div><div className="eyebrow"><span className="eyebrow-line"/> THE KILOKITE VIEW</div><h2>Your energy,<br/><span>in perspective.</span></h2></div><div className="sample-note"><span/> Illustrative sample dashboard</div></div>
      <div className="dashboard-panel">
        <div className="panel-header"><div><div className="panel-kicker">OVERVIEW / HOME</div><h3>Energy dashboard</h3></div><div className="period-switch">{['Week','Month'].map(p=><button className={period===p?'active':''} onClick={()=>setPeriod(p)} key={p}>{p}</button>)}</div></div>
        <div className="metric-grid">
          <div className="metric-card"><span><Zap size={16}/> Total consumption</span><strong>{period==='Week'?'134':'324'} <small>kWh</small></strong><em className="metric-down"><TrendingDown size={14}/> 8.4% lower</em></div>
          <div className="metric-card"><span><CircleDollarSign size={16}/> Estimated electricity bill</span><strong>₹2,268</strong><em>Based on ₹7.00 / unit</em></div>
          <div className="metric-card"><span><Leaf size={16}/> Potential savings</span><strong>₹340</strong><em className="metric-down">Illustrative 15% target</em></div>
        </div>
        <div className="chart-grid">
          <div className="chart-card"><div className="chart-title"><div><b>Electricity usage</b><small>{period==='Week'?'Daily usage this week':'Monthly usage trend'}</small></div><span className="chart-unit">kWh</span></div><div className="chart-area"><ResponsiveContainer width="100%" height="100%"><AreaChart data={data} margin={{top:10,right:8,left:-22,bottom:0}}><defs><linearGradient id="usageFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#31d6aa" stopOpacity={0.25}/><stop offset="100%" stopColor="#31d6aa" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#e9eff1" vertical={false}/><XAxis dataKey={period==='Week'?'day':'month'} axisLine={false} tickLine={false} tick={{fill:'#8b9aa3',fontSize:11}} dy={9}/><YAxis axisLine={false} tickLine={false} tick={{fill:'#8b9aa3',fontSize:11}}/><Tooltip contentStyle={{borderRadius:12,border:'1px solid #e6edef',fontSize:12}}/><Area type="monotone" dataKey={period==='Week'?'usage':'units'} stroke="#16b98d" strokeWidth={2.5} fill="url(#usageFill)" activeDot={{r:5}}/></AreaChart></ResponsiveContainer></div></div>
          <div className="insight-card"><div className="insight-card-icon"><Sparkles size={20}/></div><span className="insight-label">KILOKITE INSIGHT</span><h3>Small shifts can make a difference.</h3><p>Try running high-power appliances during cooler hours if it suits your routine. Track your usage to see whether the change helps.</p><div className="insight-bottom"><span><Check size={14}/> Practical energy habit</span><span>01 / 03</span></div></div>
        </div>
      </div>
      <p className="disclaimer">Dashboard figures are illustrative sample data for demonstration and are not live meter readings or a guaranteed bill estimate.</p>
    </div>
  </section>
}

function Calculator() {
  const [units,setUnits] = useState('324')
  const [rate,setRate] = useState('7')
  const [show,setShow] = useState(false)
  const valid = Number(units)>0 && Number(rate)>0 && Number.isFinite(Number(units)) && Number.isFinite(Number(rate))
  const bill = valid ? Number(units)*Number(rate) : 0
  const savings = bill*0.15
  return <section className="section calculator-section" id="calculator">
    <div className="container calculator-grid">
      <div className="calculator-copy"><div className="eyebrow"><span className="eyebrow-line"/> PLAN WITH CLARITY</div><h2>Know your bill.<br/><span>Find your savings.</span></h2><p className="section-lead">A simple estimate can be the first step towards more mindful energy use.</p><div className="calculator-benefit"><span><Check size={15}/></span> Quick estimate using your own numbers</div><div className="calculator-benefit"><span><Check size={15}/></span> A clear, illustrative savings target</div></div>
      <div className="calculator-box"><div className="calc-heading"><div><span className="calc-icon"><BatteryCharging size={20}/></span><h3>Energy savings calculator</h3></div><span className="calc-badge">TRY IT</span></div>
        <label>Monthly electricity consumption <span>(kWh)</span><div className="input-wrap"><input type="number" min="1" value={units} onChange={e=>{setUnits(e.target.value);setShow(false)}}/><span>kWh</span></div></label>
        <label>Electricity rate per unit <span>(₹)</span><div className="input-wrap"><span className="prefix">₹</span><input type="number" min="0.01" step="0.01" value={rate} onChange={e=>{setRate(e.target.value);setShow(false)}}/><span>/ unit</span></div></label>
        <button className="btn btn-primary calculate-btn" disabled={!valid} onClick={()=>setShow(true)}>Calculate my estimate <ArrowRight size={17}/></button>
        {show && valid ? <div className="calc-result"><div><small>ESTIMATED MONTHLY BILL</small><strong>₹{bill.toLocaleString('en-IN',{maximumFractionDigits:2})}</strong></div><div><small>ILLUSTRATIVE 15% SAVINGS TARGET</small><strong className="saving-value">₹{savings.toLocaleString('en-IN',{maximumFractionDigits:2})}</strong></div></div> : <div className="calc-placeholder"><span><Sparkles size={16}/></span> Your estimate will appear here.</div>}
        <p className="calc-footnote">Estimate = units × rate. Savings illustration assumes a 15% reduction in the estimated energy cost; actual tariffs, fixed charges, taxes and achievable savings vary.</p>
      </div>
    </div>
  </section>
}

function WhyUs() {
  const items = [
    ['Simple and user-friendly','Clear information without complicated energy jargon.',Cpu],
    ['Smart energy insights','Understand patterns and identify opportunities.',Sparkles],
    ['Cost-saving recommendations','Practical ideas to help manage consumption.',TrendingDown],
    ['Modern technology','A digital-first approach to energy awareness.',PlugZap],
    ['Easy-to-understand reports','Visual summaries that make trends easier to follow.',BarChart3]
  ]
  return <section className="section why-section"><div className="container why-grid"><div><div className="eyebrow"><span className="eyebrow-line"/> THE KILOKITE DIFFERENCE</div><h2>Better energy<br/><span>starts with insight.</span></h2><p className="section-lead">The right information makes better decisions possible. KiloKite keeps the experience focused, useful and approachable.</p></div><div className="why-list">{items.map(([title,desc,Icon],i)=><div className="why-item" key={title}><span className="why-icon"><Icon size={19}/></span><div><h3>{title}</h3><p>{desc}</p></div><span className="why-index">0{i+1}</span></div>)}</div></div></section>
}

function Contact() {
  const [form,setForm] = useState({name:'',email:'',message:''})
  const [status,setStatus] = useState('')
  const update = e => {setForm({...form,[e.target.name]:e.target.value});setStatus('')}
  const submit = e => {e.preventDefault();setStatus(`Thanks, ${form.name.trim()}! Your message has been prepared. This demo form does not send data to a server.`)}
  return <section className="section contact-section" id="contact"><div className="container contact-grid"><div><div className="eyebrow"><span className="eyebrow-line"/> START A CONVERSATION</div><h2>Let’s make energy<br/><span>make more sense.</span></h2><p className="section-lead">Have a question or an idea? We’d be glad to hear from you.</p><div className="contact-note"><span><Clock3 size={17}/></span><div><b>Thoughtful energy conversations</b><small>Tell us what you’re working towards.</small></div></div></div>
      <form className="contact-form" onSubmit={submit}><h3>Send us a message</h3><label>Your name<input name="name" value={form.name} onChange={update} placeholder="Enter your name" required minLength="2"/></label><label>Email address<input name="email" type="email" value={form.email} onChange={update} placeholder="you@example.com" required/></label><label>Message<textarea name="message" value={form.message} onChange={update} placeholder="How can we help?" rows="4" required minLength="8"/></label><button className="btn btn-primary" type="submit">Submit message <ArrowRight size={17}/></button>{status && <p className="form-status" role="status"><Check size={16}/>{status}</p>}<small className="form-hint">Demo interaction only. Connect a form service or backend to receive submissions.</small></form>
    </div></section>
}

function Footer() {
  return <footer className="footer"><div className="container"><div className="footer-main"><div><Brand light/><p>Making energy easier to understand,<br/>one unit at a time.</p></div><div className="footer-links"><b>EXPLORE</b><a href="#about">About us</a><a href="#solutions">Solutions</a><a href="#dashboard">Dashboard</a><a href="#calculator">Savings calculator</a></div><div className="footer-links"><b>GET IN TOUCH</b><a href="#contact">Contact KiloKite</a><span>Smart Energy Technology</span><span>India</span></div><div className="footer-cta"><span>EVERY UNIT. SMARTER INSIGHTS.</span><h3>Power your next<br/>better decision.</h3><a href="#contact">Let’s connect <ArrowUpRight size={16}/></a></div></div><div className="footer-bottom"><span>© 2026 KiloKite. All rights reserved.</span><span>Designed for a smarter energy future.</span></div></div></footer>
}

function App() {
  return <><Header/><main><Hero/><About/><Solutions/><Dashboard/><Calculator/><WhyUs/><Contact/></main><Footer/></>
}

createRoot(document.getElementById('root')).render(<App/>)
